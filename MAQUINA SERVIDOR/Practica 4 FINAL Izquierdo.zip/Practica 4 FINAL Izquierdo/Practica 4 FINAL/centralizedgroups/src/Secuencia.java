
import java.io.Serializable;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alex
 */
public class Secuencia implements Serializable{
    
    private int contador = 0;
    GroupMember gm;
    
    public Secuencia(GroupMember gm){
        this.gm = gm;
    }
    
    public int getContador(){
        return contador;
    }
    
    public void incrementarContador(){
         contador++;
    }
    
}
