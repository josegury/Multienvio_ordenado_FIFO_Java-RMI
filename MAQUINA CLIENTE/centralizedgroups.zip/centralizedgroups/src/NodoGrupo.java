
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alex
 */
public class NodoGrupo{
    
    ObjectGroup grupo;
    ArrayList<Secuencia> sequency = new ArrayList<>();
    
    public NodoGrupo(ObjectGroup grupo, Secuencia sequency){
        this.grupo = grupo;
        this.sequency.add(sequency);
    }
    
}
