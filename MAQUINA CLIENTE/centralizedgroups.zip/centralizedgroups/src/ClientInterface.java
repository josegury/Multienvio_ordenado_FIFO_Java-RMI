
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author usuario
 */
public interface ClientInterface extends Remote{
    
    void DepositMessage(GroupMessage m) throws RemoteException;
            
    ArrayList<Byte> receiveGroupMessage(String galias) throws RemoteException;
}
